package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TelaEditarForcaTrabalho {

    private WebDriver navegador;

    public TelaEditarForcaTrabalho(WebDriver navegador){

        this.navegador = navegador;

    }

      public TelaEditarForcaTrabalho ClicarBotaoEditar() {

        navegador.findElement(By.xpath("//html/body/app-root/app-forca-trabalho-lista/mat-card/mat-card/app-tabela-forca-trabalho/mat-table/mat-row[6]/mat-cell[8]/a")).click();
                                        //html/body/app-root/app-forca-trabalho-lista/mat-card/mat-card/app-tabela-forca-trabalho/mat-table/mat-row[6]/mat-cell[8]/a

        return this;
    }

    public TelaEditarForcaTrabalho TelaeditarClicarSelecaoVeiculo(String AlterarVeiculo) {

        try {
            Thread.sleep(150);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement input=navegador.findElement(By.xpath("//*[@id=\"mat-input-3\"]"));
        input.click();
        input.sendKeys(AlterarVeiculo); //Set the value in the element
        input.sendKeys(Keys.ENTER);

        return this;

    }


    public TelaEditarForcaTrabalho SelecaoEquipamento(String AlterarEquipamento) {

        try {
            Thread.sleep(150);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement input=navegador.findElement(By.xpath("//*[@id=\"mat-input-4\"]"));
        input.click();
        input.sendKeys(AlterarEquipamento); //Set the value in the element
        input.sendKeys(Keys.ENTER);

        return this;

    }

    public TelaEditarForcaTrabalho AlterandoForcaTrabalho(String AlterarVeiculo,String AlterarEquipamento ) {
        ClicarBotaoEditar();
        TelaeditarClicarSelecaoVeiculo(AlterarVeiculo);
        SelecaoEquipamento(AlterarEquipamento);

        return this;

    }

}
